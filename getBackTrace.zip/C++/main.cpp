#include <unistd.h>
#include <fcntl.h>
#include <execinfo.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sstream>
#include <dlfcn.h>
#include <wait.h>
#include <thread>
constexpr const int _SIZE = 4096;

void getBackTrace()
{
    void* backTracePtr[_SIZE];
    int backTraceSize = backtrace(backTracePtr, _SIZE);

    char** string = backtrace_symbols(backTracePtr, backTraceSize);

    std::stringstream btContent;

    std::stringstream _btTemp;

    int j = 0;

    char _tmp[65536];
    
    if (backTraceSize <= _SIZE)
    {
        for (int i=0; i < backTraceSize; ++i)
        {
            btContent.width(4);

            ++j;
            
            btContent << std::right << j << ":";

            Dl_info dlInfo;

            if (dladdr(backTracePtr[i], &dlInfo) == 0)
            {
                fprintf(stdout, "The address is not a part of shared object\n");
                break;
            }
            std::ptrdiff_t diff = (char*)backTracePtr[i] - (char*)dlInfo.dli_fbase - 2;

            _btTemp <<  std::hex << diff ;
            
            bool isExtractInfoSuccess = false;

            do
            {
                int pipeFd[2];
                if (pipe(pipeFd) == -1)
                {
                    fprintf(stderr, "Pipe failed with error %s\n", strerror(errno));
                    break;
                }
                
                int pid = fork();

                if (pid == -1)
                {
                    fprintf(stderr, "Pipe failed with error %s\n", strerror(errno));
                    close(pipeFd[0]);
                    close(pipeFd[1]);
                    break;
                }

                if (pid == 0)
                {
                    (void)close(pipeFd[0]);

                    if (dup2(pipeFd[1], STDOUT_FILENO) == -1)
                    {
                        fprintf(stderr, "Duplicate fd with error %s\n", strerror(errno));
                        close(pipeFd[1]);
                        break;
                    };

                    (void)close(STDERR_FILENO);

                    (void)close(pipeFd[1]);

                    if (execlp("/usr/bin/addr2line", "/usr/bin/addr2line", _btTemp.str().c_str(),"-p","-f","-C","-e", dlInfo.dli_fname, NULL) < 0)
                    {
                        exit(EXIT_FAILURE);
                    }

                    close(pipeFd[1]);

                }
                else
                {
                    (void)close(pipeFd[1]);

                    ssize_t nBytes = read(pipeFd[0], _tmp, 65536);

                    (void)close(pipeFd[0]);

                    int childStatus;

                    waitpid(pid, &childStatus,0);

                    if (childStatus !=0)
                    {
                        break;
                    }

                    if (nBytes < 65536)
                    {
                        _tmp[nBytes] = '\0';
                    }
                    btContent << _tmp  ;

                }
            } 
            while (false);
            
            _btTemp.str("");
            

            

        }
        printf("%s",btContent.str().c_str() );
    }

    else
    {
        fprintf(stdout, "Get not Enough Backtrace\n");
    }
}

void printCall(int n)
{
    if (n > 0)
    {
        printCall(--n);
    }
    else
    {
        getBackTrace();
    }
}

int main()
{

    printCall(4);

}