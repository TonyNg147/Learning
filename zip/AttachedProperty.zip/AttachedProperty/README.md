# ATTACHED PROPERTY
This is one of the most interesting attribute of QT/QML. Imagine the case that your of object doesn't actually have one specific property and it depends on the outter usage